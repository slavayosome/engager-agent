# `@engager/runner-contract`

The public, versioned JSON wire contract shared by the Engager control plane and
the local `engager-agent` executor. It contains schemas, types, protocol
constants, compatibility helpers, and canonical fixtures only. It deliberately
has no database, MCP, Next.js, provider, or runner-process implementation.

Protocol `2.1` uses leased, frozen work orders in four independent lanes:
`triage`, `draft`, `discover_draft`, and `reply`. Server receipts name every
accepted, rejected, deduplicated, or failed item; model-written summaries are
never evidence of completion.

```ts
import {
  RunnerClaimResponseSchema,
  RunnerSubmitRepliesInputSchema,
  RUNNER_CONTRACT_VERSION,
} from "@engager/runner-contract";
```

JSON timestamps are epoch milliseconds. `contractVersion` is the wire major;
minor compatibility is negotiated explicitly with `{ major, minor }`.

## Complete v2.1 surface

`RUNNER_V2_OPERATION_CONTRACTS` publishes strict request, success-response, and
error schemas for the entire nine-tool unattended surface:

- `report_runner_status`
- `claim_runner_work`
- `renew_runner_lease`
- `get_runner_work_context`
- `runner_validate_batch`
- `runner_submit_triage`
- `runner_submit_batch`
- `runner_submit_replies`
- `complete_runner_work`

Claims are server-selected and deliberately accept no lane selector. The public
claim may optionally request `claimPurpose: "setup_proof"`; omission means
`production`. The resulting work order always carries the server-persisted
`purpose`. Purpose is a one-way restriction across lease requeues: a setup
proof can never be reclaimed as production work. Submission schemas contain no
purpose field, so clients cannot spoof or relax it. For setup-proof draft and
reply orders, Engager derives proposal-only intake from the leased database row;
triage and no-like dismissals retain their normal bounded database effects.

The public schemas retain larger historical/forward-compatible work-order
ceilings, but the current Engager producer caps every frozen order at
`RUNNER_MAX_CONTEXT_ITEMS` (10). A v2.1 executor must call
`get_runner_work_context` once with the claim's complete frozen ID array in the
exact server order before any submit call; skipping it or requesting only a
subset returns `context_required`. The server materializes that complete
cognition snapshot, while overlaying live receipt progress on later crash/
reclaim reads. A successful response must return real context (or an explicit
unavailable reason) for every ID; an omitted-context skeleton is invalid.

### Materializing factored drafting context

A multi-item `draft` or `discover_draft` response can hoist byte-identical
top-level values into `sharedDraftingContext`. Executors must use the exported
helper instead of treating each item's `draftingContext` as complete:

```ts
import {
  RunnerWorkContextResponseSchema,
  materializeRunnerDraftingContext,
} from "@engager/runner-contract";

const response = RunnerWorkContextResponseSchema.parse(await getContext());
if (response.lane === "draft" || response.lane === "discover_draft") {
  for (const item of response.items) {
    const fullContext = materializeRunnerDraftingContext(response, item);
    // Pass fullContext to the user's drafting model.
  }
}
```

The merge contract is exact:

1. Shared top-level fields are copied first.
2. The item's top-level fields are copied second and win on collisions.
3. Object-valued `slop` fields are merged with the same shared-then-item
   precedence.
4. Top-level `sharedDraftingContext.slopPatterns` is transport-only. It becomes
   `slop.patterns` only when neither item nor shared `slop` already contains a
   `patterns` key; it is never returned as a top-level field.
5. A non-object item `slop` is an intentional whole-field override and wins.

The helper deep-clones JSON input. It does not mutate the parsed response, and
mutating the returned context cannot mutate shared or per-item wire values.

If a response includes `truncation`, `maxStringCharacters` applies only to
strings below an explicit `trust: "untrusted_linkedin_data"` marker. Trusted
cognition—including system prompts, Brain constraints, voice/style rules,
product gates, reply policy, and rendered reply prompts—remains byte-exact on
every successful response. The server returns `context_too_large` instead of a
success response when the complete trusted context cannot fit the wire ceiling.

Draft and reply text is bounded by both Unicode code points and UTF-8 bytes.
Every mutation carries the work-order context revision, lease token, and—for
persisting operations—an idempotency key.

## Additive v1 cutover

`RUNNER_V1_COMPATIBILITY` and `RUNNER_PROTOCOL_COMPATIBILITY_MATRIX` document
the exact v0.8.x bridge: embedded heartbeat assignment, proposal-only writes,
and its fixed tool list. The v1 artifact has its own schema and fixture and is
intentionally not accepted by `RunnerWireResponseSchema`; it cannot weaken the
strict v2.1 tagged unions.

## Compatibility and release health

`RUNNER_PROTOCOL_COMPATIBILITY_MATRIX` is the canonical support policy for
runner/server version pairs, including the additive v1 bridge.
`RUNNER_CONTRACT_HEALTH` is the release-facing summary of the current wire
protocol and supported protocol ranges. Change those exported constants with
the contract; do not maintain a separate prose matrix.
